from __future__ import division
import numpy as np
import time

from metric_mmd import compute_mmd

from julia import Main as Julia
from julia import SteinDiscrepancy


def svgd_gradient(theta, lnpgrad, subtract_mean=True, with_scale=True):

    if subtract_mean:
        theta = theta - np.mean(theta, axis=0)
    
    kxy_times_lnpgrad = np.dot(theta, np.dot(theta.T, lnpgrad)) + np.sum(lnpgrad, axis=0)
    dxKxy = theta * theta.shape[0]

    if with_scale:
        kxy_times_lnpgrad /= theta.shape[1] + 1
        dxKxy /= theta.shape[1] + 1

    kxy_times_lnpgrad /= theta.shape[0]
    dxKxy /= theta.shape[0]

    return kxy_times_lnpgrad, dxKxy


def avg_norm(x):
    x_vec = x.flatten()
    return np.sqrt(np.dot(x_vec, x_vec)/x_vec.size)


class SVGD():

    def __init__(self):
        pass
    
 
    def update(self, x0, dlnprob, n_epochs = 1, optimizer = None, model = None, saver = None, args = None, start_metrics = None):

        theta = np.copy(x0) 
        total_time = 0.0
        start_time = time.time()
        global_start_time = time.time()
        log_min_epoch = 0
        while optimizer.epoch < n_epochs:

            theta = optimizer.start_epoch(theta, model)

            for iter in range(model.dataset.num_iters_per_epoch):
                
                lnpgrad, minibatch_indices = dlnprob(theta)
                kxy_times_lnpgrad, dxkxy = svgd_gradient(theta, lnpgrad=lnpgrad)
                grad_theta = kxy_times_lnpgrad + dxkxy
                
                grad_theta = optimizer.compute_update(grad_theta, theta, model, minibatch_indices)
                theta = theta + grad_theta


                if iter+1 == model.dataset.num_iters_per_epoch:
                    n_grad_evals_over_epochs = optimizer.compute_n_grad_evals_over_epochs(iter+1, model.dataset.num_iters_per_epoch)
                    if not (n_grad_evals_over_epochs >= log_min_epoch or n_grad_evals_over_epochs >= n_epochs):
                        continue

                    total_time += time.time() - start_time

                    # Add 20 to n_epochs to account for initial SGD iterations, if any
                    if n_epochs < 20:
                        log_min_epoch += 5
                    else:
                        log_min_epoch += 5*int((n_epochs+20)//100)

                    # Check if there are any NaNs and quit
                    if np.isnan(np.sum(theta)):
                        return None


                    header = ['iter', 'n_grad_evals_over_epochs', 'time']
                    metrics = [iter+1, n_grad_evals_over_epochs, total_time]
                    if start_metrics is not None:
                        metrics[1] += start_metrics[1]
                        metrics[2] += start_metrics[2]

                    theta_mu = np.mean(theta, 0)
                    theta_cov = np.cov(theta, rowvar=False)
                    theta_std = np.sqrt(np.diag(theta_cov))

                    # If args["compute_mmd_ksd_metrics"] is False, only compute MMD at the very end
                    mmd, ksd = 1.0, 1.0

                    if args["compute_mmd_ksd_metrics"] or n_grad_evals_over_epochs >= n_epochs:
                        mmd = np.sqrt(compute_mmd(model.true_samples, theta, h_sq=model.true_samples_h_sq, true_samples_pdist=model.true_samples_pdist))

                    if args["compute_mmd_ksd_metrics"]:
                        kernel = SteinDiscrepancy.SteinInverseMultiquadricKernel()
                        result = SteinDiscrepancy.ksd(points=theta, gradlogdensity=Julia.gradlogp, kernel=kernel)
                        ksd = np.sqrt(result.discrepancy2)
                        
                    
                    header.extend(['log10_MMD', 'log10_KSD', 'norm_mu', 'norm_cov'])
                    metrics.extend([np.log10(mmd), np.log10(ksd), avg_norm(theta_mu), avg_norm(theta_cov)])

                    header.extend(['log10_MSE_mu', 'log10_MSE_std', 'log10_MSE_cov', 'norm_std'])
                    mse_mu, mse_std, mse_cov = saver.compute_MSE(theta)
                    metrics.extend([np.log10(mse_mu), np.log10(mse_std), np.log10(mse_cov), avg_norm(theta_std)])

                    header.extend(['min_std', 'max_std', 'log10_grad_theta', 'lr'])
                    metrics.extend([np.amin(theta_std), np.amax(theta_std), np.log10(avg_norm(grad_theta)), np.log10(optimizer.stepsize)])
                        
                    saver.save_metrics(header, metrics)

                    print
                    print optimizer.epoch
                    print mmd, '\t', mse_mu, '\t', mse_cov, '\t', ksd, '\t', avg_norm(theta_mu), '\t', avg_norm(theta_cov)
                    # print np.array(saver.list_metrics[-1])

                    start_time = time.time()

            optimizer.end_epoch()
        
        total_time += time.time() - start_time
        print '\n\n', total_time, ' seconds for ', n_epochs, ' epochs'
        print '\n\n', time.time() - global_start_time, ' global seconds for ', n_epochs, ' epochs'
            
        return theta
