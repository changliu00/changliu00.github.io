import numpy as np
import pandas as pd
from scipy.io import arff
import os, subprocess


def wget(url):
    filename = os.path.basename(url)
    if os.path.exists(filename):
        return
    subprocess.call('wget {}'.format(url), shell=True)


def process(dataset_name):
    base_dir = os.getcwd()

    print "\n\n\n", dataset_name, "\n"

    if not os.path.exists(dataset_name):
        os.makedirs(dataset_name)
    os.chdir(dataset_name)


    # https://archive.ics.uci.edu/ml/datasets/concrete+compressive+strength
    if dataset_name == 'concrete':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/concrete/compressive/Concrete_Data.xls')
        xls = pd.ExcelFile("Concrete_Data.xls")
        df = xls.parse(0)
    
    # https://archive.ics.uci.edu/ml/datasets/airfoil+self-noise
    elif dataset_name == 'noise':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00291/airfoil_self_noise.dat')
        df = pd.read_csv('airfoil_self_noise.dat', header=None, sep=None)
    
    # https://archive.ics.uci.edu/ml/datasets/parkinsons+telemonitoring
    elif dataset_name == 'parkinson':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/parkinsons/telemonitoring/parkinsons_updrs.data')
        df = pd.read_csv('parkinsons_updrs.data')
        
        # Predict total_UPRDS, remove motor_UPRDS
        print df.describe()
        cols = list(df.columns)
        cols = cols[0:4] + cols[6:] + [cols[5]]
        df = df[cols]

    # https://archive.ics.uci.edu/ml/datasets/bike+sharing+dataset
    elif dataset_name == 'bike':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00275/Bike-Sharing-Dataset.zip')
        if not os.path.exists('hour.csv'):
            subprocess.call('unzip Bike-Sharing-Dataset.zip', shell=True)
        df = pd.read_csv('hour.csv')

        # Drop first column (instant) and invisible second column (dteday), drop columns -3 (casual) and -2 (registered)
        print df.describe()
        cols = list(df.columns)
        cols = cols[2:-3] + [cols[-1]]
        df = df[cols]

    # https://archive.ics.uci.edu/ml/datasets/Buzz+in+social+media+
    elif dataset_name == 'toms':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00248/regression.tar.gz')
        if not os.path.exists('regression/TomsHardware/TomsHardware.data'):
            subprocess.call('tar -zxvf regression.tar.gz', shell=True)
        df = pd.read_csv('regression/TomsHardware/TomsHardware.data', header=None)


    # https://archive.ics.uci.edu/ml/datasets/Physicochemical+Properties+of+Protein+Tertiary+Structure
    elif dataset_name == 'protein':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00265/CASP.csv')
        df = pd.read_csv('CASP.csv')

        print df.describe()
        cols = list(df.columns)
        cols = cols[1:] + [cols[0]]
        df = df[cols]
    
    # https://archive.ics.uci.edu/ml/datasets/KEGG+Metabolic+Reaction+Network+(Undirected)
    # We use the last column as the target
    elif dataset_name == 'kegg':
        wget("'https://archive.ics.uci.edu/ml/machine-learning-databases/00221/Reaction%20Network%20(Undirected).data'")
        df = pd.read_csv('Reaction Network (Undirected).data', header=None)
        
        # Remove rows with '?' in column 4
        print df.describe()
        df = df[pd.to_numeric(df[df.columns[4]], errors='coerce').notnull()]

        # Drop first column (text)
        print df.describe()
        cols = list(df.columns)
        cols = cols[1:]
        df = df[cols]

        df = df.astype(float)
    
    # https://archive.ics.uci.edu/ml/datasets/3D+Road+Network+(North+Jutland,+Denmark)
    elif dataset_name == '3droad':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00246/3D_spatial_network.txt')
        df = pd.read_csv('3D_spatial_network.txt', header=None)

        # Drop first column
        print df.describe()
        cols = list(df.columns)
        cols = cols[1:]
        df = df[cols]
    
    # https://archive.ics.uci.edu/ml/datasets/yearpredictionmsd
    # We only use train: first 463,715 examples
    elif dataset_name == 'music':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00203/YearPredictionMSD.txt.zip')
        if not os.path.exists('YearPredictionMSD.txt'):
            subprocess.call('unzip YearPredictionMSD.txt.zip', shell=True)
        df = pd.read_csv('YearPredictionMSD.txt', header=None)

        print df.describe()
        cols = list(df.columns)
        cols = cols[1:] + [cols[0]]
        df = df[cols]
    
    # https://archive.ics.uci.edu/ml/datasets/Buzz+in+social+media+
    elif dataset_name == 'twitter':
        wget('https://archive.ics.uci.edu/ml/machine-learning-databases/00248/regression.tar.gz')
        if not os.path.exists('regression/Twitter/Twitter.data'):
            subprocess.call('tar -zxvf regression.tar.gz', shell=True)
        df = pd.read_csv('regression/Twitter/Twitter.data', header=None)
 

    print df.describe()
    df = df.apply(lambda x: (x - np.mean(x)) / np.std(x))
    pred = df.iloc[:, :-1]
    target = df.iloc[:, -1]

    print pred.describe()
    print target.describe()

    x_train = pred.values
    y_train = target.values

    save_path = '../../../data_linear_reg/{}'.format(dataset_name)
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    np.savetxt(os.path.join(save_path, 'x_train.txt'), x_train)
    np.savetxt(os.path.join(save_path, 'y_train.txt'), y_train)
    subprocess.call('cd {}; ln -s $PWD/x_train.txt x_test.txt'.format(save_path), shell=True)
    subprocess.call('cd {}; ln -s $PWD/y_train.txt y_test.txt'.format(save_path), shell=True)

    os.chdir(save_path)
    os.mkdir('stan')
    os.chdir('stan')
    subprocess.call('cp -a ../../stan_linear_reg/model_code.stan ../../stan_linear_reg/*.pkl .', shell=True)

    os.chdir(base_dir)


process('concrete')
process('noise')
process('parkinson')
process('bike')
process('toms')
process('protein')
process('kegg')
process('3droad')
process('music')
process('twitter')
