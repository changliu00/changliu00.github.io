#!/bin/bash

set -o noclobber
source max_bg_procs.sh

datasets=( )
datasets[1]='concrete'
datasets[2]='noise'
datasets[3]='parkinson'
datasets[4]='bike'
datasets[5]='toms'
datasets[6]='protein'
datasets[7]='kegg'
datasets[8]='3droad'
datasets[9]='music'
datasets[10]='twitter'

mkdir -p pystan_logs
cd ..

for i in "${!datasets[@]}"; do

    echo ${datasets[$i]}
    python run_pystan.py --model_type linear_reg --dataset_name ${datasets[$i]} &> datasets_linear_reg/pystan_logs/${datasets[$i]}.txt

done