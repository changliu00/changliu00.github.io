from __future__ import division
import os

import numba
import numpy as np
from numpy import matlib as nm
from scipy.spatial.distance import pdist

from dataset import Dataset
from metric_mmd import kernel_bandwidth1

from julia import Main as Julia


class BayesianLogisticReg:

    @staticmethod
    def load_dataset(dataset):
        x_train = np.loadtxt('../data/{}/x_train.txt'.format(dataset))
        X_train = np.hstack([np.ones([x_train.shape[0], 1]), x_train])
        y_train = np.loadtxt('../data/{}/y_train.txt'.format(dataset))
        y_train = y_train.astype(int)

        x_test = np.loadtxt('../data/{}/x_test.txt'.format(dataset))
        X_test = np.hstack([np.ones([x_test.shape[0], 1]), x_test])
        y_test = np.loadtxt('../data/{}/y_test.txt'.format(dataset))
        y_test = y_test.astype(int)

        return X_train, y_train, X_test, y_test

    @staticmethod
    def load(dataset, test_only=False):
        X_train, y_train, X_test, y_test = BayesianLogisticReg.load_dataset(dataset)
        stan_folder = os.path.join('../data', dataset, 'stan')

        sigma = 1.0

        if test_only:
            true_samples, true_samples_pdist, true_samples_h_sq, true_mu, true_cov = None, None, None, None, None
        else:
            true_samples = np.loadtxt(os.path.join(stan_folder, 'samples.txt'))
            # Current number of samples is 40,000. Note memory and time constraints.
            # Do not use np.square because it can double memory usage.
            true_samples_pdist = pdist(true_samples, 'sqeuclidean')
            # true_samples_h_sq = kernel_bandwidth1(true_samples)
            true_samples_h_sq = np.loadtxt(os.path.join(stan_folder, 'kernel_bandwidth.txt'))
            true_mu = np.mean(true_samples, axis=0)
            true_cov = np.cov(true_samples, rowvar=False)

        return X_train, y_train, X_test, y_test, sigma, stan_folder, true_samples, true_samples_pdist, true_samples_h_sq, true_mu, true_cov


    def __init__(self, dataset, batchsize, test_only=False):

        # Assume Y in \in {+1, -1}
        self.X, self.Y, self.X_test, self.Y_test, self.sigma, self.stan_folder, self.true_samples, self.true_samples_pdist, self.true_samples_h_sq, self.true_mu, self.true_cov = self.load(dataset, test_only)

        print "Logistic regression"
        Julia.Xs = self.X
        Julia.Ys = self.Y
        Julia.eval("""
        function gradlogp(w::Array{Float64, 1})
            pred = Xs*w
            s = StatsFuns.logistic.(pred)
            coff = (Ys + 1)/2 - s
            dw = transpose(Xs)*coff - w
            return dw
        end
        """)

        self.N = self.X.shape[0]
        self.D = self.X.shape[1]

        self.dataset = Dataset(self.N, batchsize)

        # Code to check Julia gradient with Python gradient
        # for _ in range(100):
        #     points = np.random.randn(self.D)
        #     julia_grad = Julia.gradlogp(points)
        #     our_grad = self.dlnprob(points[None, :], np.arange(self.N))
        #     assert(np.allclose(julia_grad, our_grad))
        # raise Exception('Gradient checks passed')


    def next_batch_dlnprob(self, theta):
        ridx = self.dataset.next_batch()
        return self.dlnprob(theta, ridx), ridx


    def dlnprob(self, theta, ridx):
        return self.numba_dlnprob(theta, ridx, self.X, self.Y, self.sigma)


    @staticmethod
    @numba.jit(nopython=True)
    def numba_dlnprob(theta, ridx, X, Y, b0):
        Xs = X[ridx, :]
        Ys = Y[ridx]
        w = theta

        # Assume Y in \in {+1, -1}
        coff = np.dot(Xs, w.T)
        for i in range(coff.shape[0]):
            for j in range(coff.shape[1]):
                coff[i, j] = (Ys[i] + 1)/2 - 1/(1 + np.exp(-coff[i, j]))

        dw = np.dot(coff.T, Xs)
        for i in range(dw.shape[0]):
            for j in range(dw.shape[1]):
                dw[i, j] = dw[i, j] * X.shape[0] / Xs.shape[0] - w[i, j]/(b0)**2  # re-scale

        return dw