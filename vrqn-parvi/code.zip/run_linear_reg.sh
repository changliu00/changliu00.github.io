#!/bin/bash

set -o noclobber
source max_bg_procs.sh

datasets=( )
datasets[1]='concrete'
datasets[2]='noise'
datasets[3]='parkinson'
datasets[4]='bike'
datasets[5]='toms'
datasets[6]='protein'
datasets[7]='kegg'
datasets[8]='3droad'

num_epochs=( )
num_epochs[1]=100
num_epochs[2]=100
num_epochs[3]=100
num_epochs[4]=100
num_epochs[5]=500
num_epochs[6]=100
num_epochs[7]=500
num_epochs[8]=100


for lbfgs_memory_size in 10; do
for vr_num_epochs_initial_sgd in 10; do

ALL_EXPS_FOLDER="final_code1-lbfgsM${lbfgs_memory_size}-initial_sgd_${vr_num_epochs_initial_sgd}"


for M in 100; do
for B in 10; do
for q0 in 1.0; do
for i in "${!datasets[@]}"; do


EXP_FOLDER="linear_reg-${i}-${datasets[$i]}-${num_epochs[$i]}epochs"
EXP="q0=${q0},M=${M},B=${B}"
mkdir -p ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}

OPT=svrg_lbfgs
for lr in 0.1 0.3 1 3 10 30 100 300
do
    for lr_decay in 0.00001 0.00003 0.0001 0.0003 0.001 0.003 0.01 0.03 0.1 0.3 1 3
    do
        max_bg_procs 16
        nohup python -u main.py --model_type linear_reg --dataset ${datasets[$i]} --opt ${OPT} --lr_factor ${lr} --num_epochs ${num_epochs[$i]} --all_exps_folder ${ALL_EXPS_FOLDER} --exp_folder ${EXP_FOLDER} --exp ${EXP} --B ${B} --M ${M} --q0 ${q0} --lr_decay ${lr_decay} --lbfgs_memory_size ${lbfgs_memory_size} --vr_num_epochs_initial_sgd ${vr_num_epochs_initial_sgd} > ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}/${OPT}_lr${lr}_lrdecay${lr_decay}.txt 2>&1 &
    done
done

OPT=svrg
for lr in 0.1 0.3 1 3 10 30 100 300
do
    for lr_decay in 1 3 10 30 100 300 1000
    do
        max_bg_procs 16
        nohup python -u main.py --model_type linear_reg --dataset ${datasets[$i]} --opt ${OPT} --lr_factor ${lr} --num_epochs ${num_epochs[$i]} --all_exps_folder ${ALL_EXPS_FOLDER} --exp_folder ${EXP_FOLDER} --exp ${EXP} --B ${B} --M ${M} --q0 ${q0} --lr_decay ${lr_decay} --vr_num_epochs_initial_sgd ${vr_num_epochs_initial_sgd} > ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}/${OPT}_lr${lr}_lrdecay${lr_decay}.txt 2>&1 &
    done
done

OPT=spider
for lr in 0.1 0.3 1 3 10 30 100 300
do
    for lr_decay in 1 3 10 30 100 300 1000
    do
        max_bg_procs 16
        nohup python -u main.py --model_type linear_reg --dataset ${datasets[$i]} --opt ${OPT} --lr_factor ${lr} --num_epochs ${num_epochs[$i]} --all_exps_folder ${ALL_EXPS_FOLDER} --exp_folder ${EXP_FOLDER} --exp ${EXP} --B ${B} --M ${M} --q0 ${q0} --lr_decay ${lr_decay} --vr_num_epochs_initial_sgd ${vr_num_epochs_initial_sgd} > ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}/${OPT}_lr${lr}_lrdecay${lr_decay}.txt 2>&1 &
    done
done

OPT=sgd
for lr in 0.1 0.3 1 3 10 30 100 300
do
    for lr_decay in 0 3 10 30 100 300 1000
    do
        for power in 0.55 0.75 0.95
        do
            max_bg_procs 16
            nohup python -u main.py --model_type linear_reg --dataset ${datasets[$i]} --opt ${OPT} --lr_factor ${lr} --num_epochs ${num_epochs[$i]} --all_exps_folder ${ALL_EXPS_FOLDER} --exp_folder ${EXP_FOLDER} --exp ${EXP} --B ${B} --M ${M} --q0 ${q0} --lr_decay ${lr_decay} --power ${power} > ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}/${OPT}_lr${lr}_lrdecay${lr_decay}_power${power}.txt 2>&1 &
        done
    done
done

OPT=adagrad
for lr in 0.1 0.3 1 3 10 30 100 300
do
    for lr_decay in 0.9 0.95 0.99 0.999
    do
        for power in 1e-4 1e-5 1e-6 1e-7 1e-8
        do
            max_bg_procs 16
            nohup python -u main.py --model_type linear_reg --dataset ${datasets[$i]} --opt ${OPT} --lr_factor ${lr} --num_epochs ${num_epochs[$i]} --all_exps_folder ${ALL_EXPS_FOLDER} --exp_folder ${EXP_FOLDER} --exp ${EXP} --B ${B} --M ${M} --q0 ${q0} --lr_decay ${lr_decay} --power ${power} > ../${ALL_EXPS_FOLDER}/${EXP_FOLDER}/logs/${EXP}/${OPT}_lr${lr}_lrdecay${lr_decay}_power${power}.txt 2>&1 &
        done
    done
done


done
done
done
done
done
done
