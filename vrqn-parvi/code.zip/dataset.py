from __future__ import division
import numpy as np


class Dataset:

    def __init__(self, N, batchsize):
        self.N = N
        self.batchsize = batchsize

        # Assumes that any leftover mini-batch is discarded
        self.num_iters_per_epoch = int(N / batchsize)

        self.permutation = np.random.permutation(N)
        self.iter = 0


    def next_batch(self):
        batch = [ i % self.N for i in range(self.iter * self.batchsize, (self.iter + 1) * self.batchsize) ]
        ridx = self.permutation[batch]
        self.iter += 1

        if self.iter == self.num_iters_per_epoch:
            self.permutation = np.random.permutation(self.N)
            self.iter = 0

        return ridx
