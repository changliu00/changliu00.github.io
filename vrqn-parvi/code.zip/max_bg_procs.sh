pgrep_running() {
    pgrep -c 'julia|python|matlab|R'
}

# https://stackoverflow.com/questions/1537956/bash-limit-the-number-of-concurrent-jobs
max_bg_procs() {
    if [ $# -eq 0 ] ; then
            echo "Usage: max_bg_procs NUM_PROCS.  Will wait until the number of background (&)"
            echo "           bash processes (as determined by 'jobs -pr') falls below NUM_PROCS"
            return
    fi
    local max_number=$((0 + ${1:-0}))
    while true; do
            sleep 0.1
            local current_number=$(pgrep_running)
            if [ $current_number -lt $max_number ]; then
                break
            fi
            sleep 10
    done
}
