from __future__ import division
import numpy as np
from svgd import svgd_gradient
from lbfgs_py import LBFGS
import time

class Opt_SVRG:

    def __init__(self, args, stepsize = 1e-3, num_epochs=0, lr_decay=1, opt=None, model=None):
        self.name = 'svrg'

        self.initial_stepsize = stepsize
        self.stepsize = stepsize

        self.epoch = 0
        self.num_epochs = num_epochs
        self.lr_decay = lr_decay

        self.snapshot_theta = None
        self.full_gradient = None

        self.opt = opt
        if opt == "svrg_lbfgs":
            # L-BFGS
            self.M = args["lbfgs_memory_size"]
            self.eta1 = self.stepsize
            self.eta2 = self.lr_decay
            self.lbfgs = LBFGS(model, self.M, self.eta1, self.eta2, args["M"])
        elif opt == "svrg":
            pass
        else:
            raise Exception("SVRG optimizer name invalid")


    def svgd_variance_reduction_term(self, theta, model, minibatch_indices):
        stale_gradient = model.dlnprob(self.snapshot_theta, minibatch_indices)
        variance_reduced_gradient = -stale_gradient + self.full_gradient
        variance_reduced_term, _ = svgd_gradient(self.snapshot_theta, lnpgrad=variance_reduced_gradient)
        return variance_reduced_term


    def compute_update(self, grad_theta, theta, model, minibatch_indices):

        variance_reduction_term = self.svgd_variance_reduction_term(theta, model, minibatch_indices)
        grad_theta = grad_theta + variance_reduction_term

        if self.opt == "svrg":
            return self.stepsize * grad_theta
        
        elif self.opt == "svrg_lbfgs":
            return self.lbfgs.compute_quasi_newton_update(grad_theta)


    def start_epoch(self, theta, model):
        all_gradients = []
        for iter in range(model.dataset.num_iters_per_epoch):
            lnpgrad, minibatch_indices = model.next_batch_dlnprob(theta)
            all_gradients.append(lnpgrad)
        self.full_gradient = np.mean(all_gradients, axis=0)

        if self.opt == "svrg_lbfgs":
            self.lbfgs.update_epoch(theta, self.full_gradient)
        
        self.snapshot_theta = np.copy(theta)
        self.epoch += 1

        return theta


    def end_epoch(self):
        self.epoch += 2
        if self.opt == "svrg":
            if self.epoch >= self.num_epochs//2:
                self.stepsize = self.initial_stepsize/self.lr_decay


    def compute_n_grad_evals_over_epochs(self, iter, num_iters_per_epoch):
        return self.epoch + 2*iter/float(num_iters_per_epoch)