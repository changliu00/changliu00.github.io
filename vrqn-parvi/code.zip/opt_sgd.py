from __future__ import division
import numpy as np

class Opt_SGD:

    def __init__(self, stepsize=1e-3, num_epochs=0, lr_decay=0, power=0.55):
        self.name = 'sgd'

        self.initial_stepsize = stepsize
        self.stepsize = stepsize

        self.epoch = 0
        self.num_epochs = num_epochs
        self.lr_decay = lr_decay
        self.power = power

        
    def compute_update(self, grad_theta, *args):
        return self.stepsize * grad_theta
    
    def start_epoch(self, theta, model):
        return theta
    
    def end_epoch(self):
        self.epoch += 1
        if self.lr_decay > 0:
            b = 100 / ((1.0 / self.lr_decay) ** (-1 / self.power) - 1)
            a = 1 / b ** (-self.power)
            self.stepsize = self.initial_stepsize*a*(b + self.epoch*100/self.num_epochs)**(-self.power)

    def compute_n_grad_evals_over_epochs(self, iter, num_iters_per_epoch):
        return self.epoch + iter/float(num_iters_per_epoch)