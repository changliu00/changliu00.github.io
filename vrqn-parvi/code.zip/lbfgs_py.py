import numpy as np
import numba
from svgd import svgd_gradient

class LBFGS:

    def __init__(self, model, m, eta1, eta2, num_particles):
        self.model = model
        self.D = num_particles*model.D

        # Keep track of most recent m
        self.m = m
        self.eta1 = eta1
        self.eta2 = eta2
        
        self.last_idx = -1
        self.num_added = 0
        self.s = np.zeros((self.m, self.D))
        self.y = np.zeros((self.m, self.D))
        
        self.rho = np.zeros(self.m)
        self.alpha = np.zeros(self.m)

        self.last_x = None
        self.last_full_gradient = None
    
    
    @staticmethod
    @numba.jit(nopython=True)
    def two_loop_recursion(q, H0, y, s, m, rho, alpha, last_idx, num_added):

        for c in range(num_added):
            i = (last_idx - c) % m
            rho[i] = 1/np.dot(y[i], s[i])
            alpha[i] = rho[i] * np.dot(s[i], q)
            q = q - alpha[i] * y[i]
        
        r = H0*q

        if num_added < m:
            for i in range(num_added):
                beta = rho[i] * np.dot(y[i], r)
                r = r + s[i]*(alpha[i] - beta)

        else:
            for c in range(num_added):
                i = (last_idx + 1 + c) % m
                beta = rho[i] * np.dot(y[i], r)
                r = r + s[i]*(alpha[i] - beta)
        
        return r.reshape(-1)
    

    def store_pairs(self, new_y, new_s):
        self.last_idx = (self.last_idx + 1) % (self.m)
        self.y[self.last_idx] = new_y
        self.s[self.last_idx] = new_s
        if self.num_added < self.m:
            self.num_added += 1
    

    def update_epoch(self, x_k, full_gradient):
        if self.last_full_gradient is None:
            self.last_full_gradient = np.copy(full_gradient)
            self.last_x = np.copy(x_k)
        else:
            new_s = x_k - self.last_x
            curr_kxy_times_lnpgrad, curr_dxKxy = svgd_gradient(x_k, lnpgrad=full_gradient)
            prev_kxy_times_lnpgrad, prev_dxKxy = svgd_gradient(self.last_x, lnpgrad=self.last_full_gradient)
            new_y = curr_kxy_times_lnpgrad + curr_dxKxy - (prev_kxy_times_lnpgrad + prev_dxKxy)
            self.store_pairs(new_y.reshape(-1), new_s.reshape(-1))
            self.last_full_gradient = np.copy(full_gradient)
            self.last_x = np.copy(x_k)
        return


    def compute_quasi_newton_update(self, grad_f_k):
        if self.num_added > 1:
            H0 = np.dot(self.s[self.last_idx], self.y[self.last_idx])/np.dot(self.y[self.last_idx], self.y[self.last_idx])
            p_k = -LBFGS.two_loop_recursion(grad_f_k.reshape(-1), H0, self.y, self.s, self.m, self.rho, self.alpha, self.last_idx, self.num_added)
            p_k = p_k.reshape(grad_f_k.shape)
            return self.eta2*p_k
        else:
            p_k = grad_f_k
            return self.eta1*p_k