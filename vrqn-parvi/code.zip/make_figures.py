from __future__ import division
import sys, os, glob, subprocess
import collections
import numpy as np
from plot_config import setup_plots, get_fig_size
import matplotlib
matplotlib.use("pgf")
import matplotlib.pyplot as plt


def get_best_experiments():
    best_results = collections.OrderedDict([("svrg_lbfgs", (np.float("inf"), "")), ("svrg", (np.float("inf"), "")), ("spider", (np.float("inf"), "")), ("sgd", (np.float("inf"), "")), ("adagrad", (np.float("inf"), ""))])
    for f in glob.glob("opt*.txt"):
        arr = np.loadtxt(f)
        final_mmd = arr[-1, 3]
        optimizer_name = f.split('opt=')[1].split(',')[0]
        if final_mmd < best_results[optimizer_name][0]:
            best_results[optimizer_name] = (final_mmd, f, arr)
    return best_results


def get_header(filename):
    with open(filename, "r") as f:
        header = f.readline().rstrip("\n")
        return header.split('\t')


def get_label(alg_name, final_metric):
    if "svrg_lbfgs" in alg_name:
        name = "SQN-VR"
    elif "svrg" in alg_name:
        name = "SVRG"
    elif "spider" in alg_name:
        name = "SPIDER"
    elif "sgd" in alg_name:
        name = "SGD"
    elif "adagrad" in alg_name:
        name = "AdaGrad"
    else:
        raise Exception("Optimizer name not recognized")
    return name
    # return "{0:.2f}".format(final_metric) + "  " + name


def get_x_label(x_label):
    return "\# grad / N"


def get_y_label(y_label):
    if y_label == "log10_MMD":
        return "log10(MMD)"
    elif y_label == "log10_MSE_mu":
        return "log10(MSE_mu)"
    elif y_label == "log10_MSE_cov":
        return "log10(MSE_cov)"
    elif y_label == "log10_KSD":
        return "log10(KSD)"
    else:
        return y_label


exp_folder = ["q0=1.0,M=100,B=10"]

if len(sys.argv) > 1:
    # Assumes ../
    all_exps_folder = sys.argv[1]
else:
    all_exps_folder = '../exps'
os.chdir(all_exps_folder)

setup_plots(font_size=12, axes_labelsize=16)
subprocess.call("mkdir -p figures", shell=True)
subprocess.call("mkdir -p figures_all", shell=True)
base_folder = os.getcwd()

for big_exp_folder in sorted(glob.glob("*reg-*/")):
    os.chdir(base_folder)
    os.chdir(big_exp_folder)

    for folder in exp_folder:
        print big_exp_folder, ":",
        try:
            os.chdir(os.path.join('metrics'))
            os.chdir(folder)
        except:
            continue
        
        best_experiments = get_best_experiments().values()
        try:
            _, list_alg_names, list_metrics = zip(*best_experiments)
        except:
            print "Skipped"
            continue
        print list_alg_names
        exp_colors = ["C0", "C1", "C2", "C3", "C4"]

        header = get_header(list_alg_names[0])

        x_index = 1
        x_label = header[x_index]
        y_indices = range(3, len(header))
        y_labels = [header[y_i] for y_i in y_indices]

        for y_label, y_index in zip(y_labels, y_indices):
            fig = plt.figure(figsize=get_fig_size(width_percent_scale=1, width_to_height_ratio = 1.33))

            for alg_name, metrics, color in zip(list_alg_names, list_metrics, exp_colors):
                plt.plot(metrics[:, x_index], metrics[:, y_index], marker='.', color=color, label=get_label(alg_name, metrics[-1, y_index]))
            plt.xlabel(get_x_label(x_label))
            plt.ylabel(get_y_label(y_label))
            plt.legend()
            plt.tight_layout()
            plt.savefig('plot_' + y_label + '.pdf')
            plt.close()

        output_name = big_exp_folder[:-1]

        input_files = ['plot_%s.pdf' % s for s in y_labels]
        input_str = ' '.join(input_files)
        # subprocess.call("montage -mode concatenate -tile 4x " + input_str + " ../../../figures_all/" + output_name + ".png", shell=True)
        output_path = " ../../../figures_all/" + output_name + ".pdf"
        subprocess.call("pdfjam --nup 4x3 --landscape --clip true --quiet " + input_str + " --outfile " + output_path, shell=True)
        subprocess.call("pdfcrop " + output_path + output_path + " > /dev/null", shell=True)

        input_files = ['plot_%s.pdf' % s for s in [y_labels[0], y_labels[4], y_labels[6], y_labels[1]]]
        input_str = ' '.join(input_files)
        # subprocess.call("montage -mode concatenate -tile 4x " + input_str + " ../../../figures/" + output_name + ".png", shell=True)
        output_path = " ../../../figures/" + output_name + ".pdf"
        subprocess.call("pdfjam --nup 4x1 --landscape --clip true --quiet " + input_str + " --outfile " + output_path, shell=True)
        subprocess.call("pdfcrop " + output_path + output_path + " > /dev/null", shell=True)
        
        # subprocess.call("rm " + input_str, shell=True)

os.chdir(base_folder)
subprocess.call("pdfjam --nup 1x8 --clip true --quiet figures/*linear_reg* --outfile figures/linear_reg.pdf", shell=True)
subprocess.call("pdfjam --nup 1x7 --clip true --quiet figures/*logistic_reg* --outfile figures/logistic_reg.pdf", shell=True)