import numpy as np
from scipy.spatial.distance import pdist, cdist, squareform
import numba
import numexpr as ne

def kernel_bandwidth1(theta):
    pairwise_dists = squareform(pdist(theta, 'sqeuclidean'))
    h_sq = np.median(pairwise_dists)
    print pairwise_dists.shape, h_sq
    return h_sq

def rbf_kernel(theta, theta2, h_sq):
    pairwise_dists = np.square(cdist(theta, theta2))
    # compute the rbf kernel
    Kxy = np.exp( -pairwise_dists / (2*h_sq) )
    return Kxy

def compute_mmd(theta1, theta2, h_sq=0.0, true_samples_pdist=None):
    m = theta1.shape[0]
    n = theta2.shape[0]
    if true_samples_pdist is None:
        k11 = np.sum(rbf_kernel(theta1, theta1, h_sq))/m**2
    else:
        k11 = (2*numexpr_sum_rbf_kernel(true_samples_pdist, h_sq) + m) / m ** 2
    k22 = np.sum(rbf_kernel(theta2, theta2, h_sq))/n**2
    k12 = np.sum(rbf_kernel(theta1, theta2, h_sq))/(m*n)
    return k11 + k22 - 2*k12

@numba.jit(nopython=True)
def numba_sum_rbf_kernel(true_samples_pdist, h_sq):
    # np.sum(np.exp( -true_samples_pdist / (2*h_sq) ))
    m = true_samples_pdist.shape[0]
    s = 0.0
    for i in range(m):
        s += np.exp( -true_samples_pdist[i] / (2*h_sq) )
    return s

def numexpr_sum_rbf_kernel(true_samples_pdist, h_sq):
    # np.sum(np.exp( -true_samples_pdist / (2*h_sq) ))
    return ne.evaluate("sum(exp( -true_samples_pdist / (2*h_sq) ))")

def test_sum_rbf_kernel():
    import time
    true_samples_pdist = np.random.rand(40000*(40000-1)/2)
    h_sq = 0.1
    for _ in range(3):
        s = time.time(); print np.sum(np.exp( -true_samples_pdist / (2*h_sq) )), ; print "\t", time.time() - s
        s = time.time(); print numba_sum_rbf_kernel(true_samples_pdist, h_sq), ; print "\t", time.time() - s
        s = time.time(); print numexpr_sum_rbf_kernel(true_samples_pdist, h_sq), ; print "\t", time.time() - s

if __name__ == '__main__':
    test_sum_rbf_kernel()