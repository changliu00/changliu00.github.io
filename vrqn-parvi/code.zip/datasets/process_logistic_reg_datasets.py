import numpy as np
import pandas as pd
from scipy.io import arff
import os, subprocess

def process(dataset_name):
    if not os.path.exists(dataset_name):
        os.makedirs(dataset_name)
        os.chdir(dataset_name)


    # https://www.kaggle.com/uciml/pima-indians-diabetes-database
    if dataset_name == 'pima':
        df = pd.read_csv('diabetes.csv')

    # https://archive.ics.uci.edu/ml/datasets/Diabetic+Retinopathy+Debrecen+Data+Set
    elif dataset_name == 'diabetic':
        subprocess.call('wget https://archive.ics.uci.edu/ml/machine-learning-databases/00329/messidor_features.arff', shell=True)
        data, meta = arff.loadarff('messidor_features.arff')
        df = pd.DataFrame(data)
        df = df.astype(float)
    
    # https://archive.ics.uci.edu/ml/datasets/EEG+Eye+State
    elif dataset_name == 'eeg':
        subprocess.call('wget https://archive.ics.uci.edu/ml/machine-learning-databases/00264/EEG%20Eye%20State.arff', shell=True)
        data, meta = arff.loadarff('EEG Eye State.arff')
        df = pd.DataFrame(data)
        df = df.astype(float)
    
    elif dataset_name == 'space':
        subprocess.call('wget https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/shuttle.trn.Z', shell=True)
        subprocess.call('uncompress shuttle.trn.Z', shell=True)
        subprocess.call('wget https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/shuttle.tst', shell=True)
        df_train = pd.read_csv('shuttle.trn', header=None, sep=' ')
        df_test = pd.read_csv('shuttle.tst', header=None, sep=' ')
        df = pd.concat([df_train, df_test])

        # Convert to binary classification
        target = df.iloc[:, -1].values
        print np.sum(target == 1)
        print np.sum(target > 1)
        target[target > 1] = 0
        print np.sum(target == 1)
        print np.sum(target == 0)
        df.iloc[:, -1] = target
        
    elif dataset_name == 'susy':
        subprocess.call('wget https://archive.ics.uci.edu/ml/machine-learning-databases/00279/SUSY.csv.gz', shell=True)
        subprocess.call('gunzip SUSY.csv.gz', shell=True)
        subprocess.call('head -n 100000 SUSY.csv > susy.csv', shell=True)
        subprocess.call('rm SUSY.csv', shell=True)
        df = pd.read_csv('susy.csv', header=None)

        print df.describe()
        cols = list(df.columns)
        cols = cols[1:] + [cols[0]]
        df = df[cols]
        

    print df.describe()
    pred = df.iloc[:, :-1]
    target = df.iloc[:, -1]

    pred = pred.apply(lambda x: (x - np.mean(x)) / np.std(x))
    print pred.describe()
    target = 2*target - 1
    print target.describe()

    x_train = pred.values
    y_train = target.values

    save_path = '../../../data/{}'.format(dataset_name)
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    np.savetxt(os.path.join(save_path, 'x_train.txt'), x_train)
    np.savetxt(os.path.join(save_path, 'y_train.txt'), y_train)
    np.savetxt(os.path.join(save_path, 'x_test.txt'), x_train)
    np.savetxt(os.path.join(save_path, 'y_test.txt'), y_train)

    os.chdir(save_path)
    os.mkdir('stan')
    os.chdir('stan')
    subprocess.call('cp -a ../../stan_logistic_reg/model_code.stan ../../stan_logistic_reg/*.pkl .', shell=True)

process('susy')