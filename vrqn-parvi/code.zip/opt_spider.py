from __future__ import division
import numpy as np
from svgd import svgd_gradient

class Opt_SPIDER:

    def __init__(self, args, stepsize = 1e-3, num_epochs=0, lr_decay=1):
        self.name = 'spider'

        self.initial_stepsize = stepsize
        self.stepsize = stepsize

        self.epoch = 0
        self.num_epochs = num_epochs
        self.lr_decay = lr_decay

        self.prev_theta = None
        self.prev_gradient = None


    def svgd_variance_reduction_term(self, theta, model, minibatch_indices):
        stale_gradient = model.dlnprob(self.prev_theta, minibatch_indices)
        stale_kxy_times_lnpgrad, stale_dxkxy = svgd_gradient(self.prev_theta, lnpgrad=stale_gradient)
        variance_reduced_term = -stale_kxy_times_lnpgrad - stale_dxkxy + self.prev_gradient
        return variance_reduced_term


    @staticmethod
    def norm_gradient(grad_theta):
        num_particles = grad_theta.shape[0]
        inner_product = np.dot(grad_theta.reshape(-1), grad_theta.reshape(-1))/num_particles
        return grad_theta/np.sqrt(inner_product)


    def compute_update(self, grad_theta, theta, model, minibatch_indices):

        variance_reduction_term = self.svgd_variance_reduction_term(theta, model, minibatch_indices)
        grad_theta = grad_theta + variance_reduction_term

        self.prev_theta = np.copy(theta)
        self.prev_gradient = np.copy(grad_theta)

        return self.stepsize * self.norm_gradient(grad_theta)


    def start_epoch(self, theta, model):
        all_gradients = []
        for iter in range(model.dataset.num_iters_per_epoch):
            lnpgrad, minibatch_indices = model.next_batch_dlnprob(theta)
            all_gradients.append(lnpgrad)
        lnpgrad = np.mean(all_gradients, axis=0)
        kxy_times_lnpgrad, dxkxy = svgd_gradient(theta, lnpgrad=lnpgrad)
        grad_theta = kxy_times_lnpgrad + dxkxy
        
        self.prev_theta = np.copy(theta)
        self.prev_gradient = np.copy(grad_theta)
        self.epoch += 1

        return theta + self.stepsize * self.norm_gradient(grad_theta)


    def end_epoch(self):
        self.epoch += 2
        if self.epoch >= self.num_epochs//2:
            self.stepsize = self.initial_stepsize/self.lr_decay


    def compute_n_grad_evals_over_epochs(self, iter, num_iters_per_epoch):
        return self.epoch + 2*iter/float(num_iters_per_epoch)