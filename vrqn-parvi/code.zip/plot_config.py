from __future__ import division
from __future__ import print_function
import os, glob, sys, re
import numpy as np
import matplotlib
matplotlib.use("pgf")
import matplotlib.pyplot as plt

print(matplotlib.__version__)

def setup_plots(font_size=10, axes_labelsize=10):
    matplotlib.rcParams.update({
        "pgf.texsystem": "pdflatex",
        'font.family': 'serif',
        'text.usetex': True,
        'pgf.rcfonts': False,
        "font.size": font_size,
        "axes.labelsize": axes_labelsize,
    })

def get_fig_size(width_percent_scale, width_to_height_ratio):
    latex_col_width = 5.50107
    return (latex_col_width*width_percent_scale, latex_col_width*width_percent_scale/width_to_height_ratio)