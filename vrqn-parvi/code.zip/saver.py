from __future__ import division
import numpy as np

class Saver:
    def __init__(self, model):
        self.list_metrics = []
        self.header_metrics = None
        np.set_printoptions(suppress=True, linewidth=400)

        self.true_mu, self.true_cov = model.true_mu, model.true_cov

    def compute_MSE(self, theta):
        mse_mu = np.mean(np.square(self.true_mu - np.mean(theta, 0)))
        theta_cov = np.cov(theta, rowvar=False)
        mse_std = np.mean(np.square(np.sqrt(np.diag(self.true_cov)) - np.sqrt(np.diag(theta_cov))))
        mse_cov = np.mean(np.square(self.true_cov - theta_cov))
        return mse_mu, mse_std, mse_cov
        

    def save_metrics(self, header, metrics):
        if self.header_metrics is None:
            self.header_metrics = header
        self.list_metrics.append(metrics)

    
    def get_metrics(self):
        return np.array(self.list_metrics)