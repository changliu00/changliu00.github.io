1. datasets and datasets_linear_reg folders are for downloading and pre-processing the datasets.
2. run_pystan.py runs NUTS and saves the NUTS samples.
3. run_linear_reg.sh and run_logistic_reg.sh (calls main.py) runs all of the experiments. To compute the MMD and KSD metrics, pass the --compute_mmd_ksd_metrics flag to main.py, or first run main.py without the --compute_mmd_ksd_metrics flag, then run make_figures.py to get the best hyperparameters, and finally run rerun.py.


Python 2.7 dependencies:
- numpy
- scipy
- numba
- numexpr
- pystan
- pyjulia
- pandas
- matplotlib

Julia 0.6 dependencies:
- SteinDiscrepancy.jl

To make figures:
- pdfjam
- pdfcrop