from __future__ import division
import os
import subprocess

import numpy as np

from bayesian_linear_regression import BayesianLinearReg
from bayesian_logistic_regression import BayesianLogisticReg
from svgd import SVGD
from opt_sgd import Opt_SGD
from opt_adagrad import Opt_Adagrad
from opt_svrg import Opt_SVRG
from opt_spider import Opt_SPIDER
from saver import Saver
import argparse


def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--opt", help="Optimizer")
    parser.add_argument("--B", type=int, help="Batch size", default=10)

    parser.add_argument("--lr_factor", help="Learning rate factor (use this as input)", type=float, default=1.0)
    parser.add_argument("--lr", help="Learning rate (automatically computed by dividing lr_factor by N)", type=float, default=0.0)
    parser.add_argument("--lr_decay", help="Learning rate decay in SGD, SVRG, SPIDER; quasi-Newton learning rate in SQN-VR; alpha in AdaGrad", type=float, default=100)
    parser.add_argument("--power", help="Power for learning rate decay in SGD; fudge factor epsilon in AdaGrad", type=float, default=0.55)

    parser.add_argument("--vr_num_epochs_initial_sgd", help="For VR optimizers, number of epochs for initial SGD run", type=int, default=10)
    parser.add_argument("--lbfgs_memory_size", help="L-BFGS memory size", type=int, default=10)

    parser.add_argument("--num_epochs", help="Number of passes over the dataset", type=int, default=100)

    parser.add_argument("--M", help="Number of particles", type=int, default=100)
    parser.add_argument("--q0", help="Initialization standard deviation for particles", type=float, default=1.0)

    parser.add_argument("--model_type", default="logistic_reg", help="logistic_reg, linear_reg")
    parser.add_argument("--dataset", default="covtype", help="Name of dataset")
    
    parser.add_argument("--all_exps_folder", default='exps', help="Name for all experiments folder")
    parser.add_argument("--exp_folder", default='exp_folder', help="Name for experiment folder")
    parser.add_argument("--exp", default='exp', help="Name for experiment")
    parser.add_argument("--compute_mmd_ksd_metrics", action='store_true', help="Compute MMD and KSD metrics (longer running time)")

    args = parser.parse_args()
    
    for arg in vars(args):
        print arg, getattr(args, arg)

    return vars(args)


def args_to_header_and_row(args):
    keys = ["opt",  "lr_factor",  "lr_decay", "power"]
    vals = [args[k] for k in keys]
    return keys, vals


def args_to_str(args):
    keys, _ = args_to_header_and_row(args)
    return ",".join(("{}={}".format(k, args[k]) for k in keys))    

def string_to_dict(s):
    list_s = [x.split('=') for x in s.split(',')]
    d_s = {x[0]: x[1] for x in list_s}
    return d_s


if __name__ == '__main__':

    args = get_arguments()
    os.chdir('../' + args['all_exps_folder'])

    model_str = args["model_type"] + "_" + args["dataset"]
    np.random.seed(hash(model_str) & 0xffffffff)
    
    print args["dataset"]
    if args["model_type"] == 'logistic_reg':
        model = BayesianLogisticReg(args["dataset"], args["B"])
    elif args["model_type"] == 'linear_reg':
        model = BayesianLinearReg(args["dataset"], args["B"])
    D = model.D

    # Initialization
    M = args["M"]  # number of particles
    theta0 = np.zeros([M, D])
    for i in range(M):
        theta0[i, :] = np.hstack([np.random.normal(0, args["q0"], D)])
    num_epochs = args["num_epochs"]

    # Automatically scale learning rate by number of training points
    args["lr"] = args["lr_factor"]/model.N
    if args["opt"] == "adagrad":
        optimizer = Opt_Adagrad(stepsize=args["lr"], alpha=args["lr_decay"], fudge_factor=args["power"])    
    elif args["opt"] == "sgd":
        optimizer = Opt_SGD(stepsize=args["lr"], num_epochs=num_epochs, lr_decay=args["lr_decay"], power=args["power"])
    elif args["opt"] == "svrg" or args["opt"] == "svrg_lbfgs" or args["opt"] == "spider":
        optimizer = Opt_SGD(stepsize=args["lr"], num_epochs=args["vr_num_epochs_initial_sgd"])
        num_epochs = args["vr_num_epochs_initial_sgd"]

    else:
        raise Exception("Optimizer not recognized")
    
    print "Initial learning rate = ", optimizer.stepsize
    
    saver = Saver(model)
    theta = SVGD().update(x0=theta0, dlnprob=model.next_batch_dlnprob, n_epochs=num_epochs, optimizer=optimizer, model=model, saver=saver, args=args)
    if theta is None:
        exit()

    if args["opt"] == "svrg" or args["opt"] == "svrg_lbfgs" or args["opt"] == "spider":
        metrics = saver.get_metrics()
        start_metrics = metrics[-1, 0:3]

        if args["opt"] == "svrg" or args["opt"] == "svrg_lbfgs":
            optimizer = Opt_SVRG(args, stepsize=args["lr"], num_epochs=args["num_epochs"]-num_epochs, lr_decay=args["lr_decay"], opt=args["opt"], model=model)
        elif args["opt"] == "spider":
            optimizer = Opt_SPIDER(args, stepsize=args["lr"], num_epochs=args["num_epochs"]-num_epochs, lr_decay=args["lr_decay"])

        theta = SVGD().update(x0=theta, dlnprob=model.next_batch_dlnprob, n_epochs=args["num_epochs"]-num_epochs, optimizer=optimizer, model=model, saver=saver, args=args, start_metrics=start_metrics)
        if theta is None:
            exit()

    print "Final learning rate = ", optimizer.stepsize

    print '\n\nMean: ', np.mean(theta, 0)
    print 'Std:  ', np.std(theta, 0)

    metrics = saver.get_metrics()
    print "\n\n", metrics
    save_path = os.path.join(args['exp_folder'], 'metrics', args['exp'])
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    header_metrics = "\t".join(saver.header_metrics)
    np.savetxt(os.path.join(save_path, args_to_str(args) + '.txt'), metrics, delimiter='\t', header=header_metrics)
    with open(os.path.join(save_path, "header.txt"), "w") as f:
        f.write("# ")
        f.write(header_metrics)
    
    # Write summary table
    table_header = ["Name"]
    table_row = [args_to_str(args)]
    
    table_header.extend(saver.header_metrics[3:11])
    table_row.extend(metrics[-1, 3:11])
    
    keys, vals = args_to_header_and_row(args)
    table_header.extend(keys)
    table_row.extend(vals)

    print
    print table_header
    print table_row

    if not os.path.exists(os.path.join(save_path, "table.txt")):
        with open(os.path.join(save_path, "table.txt"), "w") as f:
            f.write("\t".join(table_header))
            f.write("\n")

    
    with open(os.path.join(save_path, "table.txt"), "a") as f:
        f.write("\t".join([str(x) for x in table_row]))
        f.write("\n")
