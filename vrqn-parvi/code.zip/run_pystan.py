import os, sys
import pystan
import numpy as np
import argparse

from bayesian_logistic_regression import BayesianLogisticReg
from bayesian_linear_regression import BayesianLinearReg

import pickle, io
from hashlib import md5
def StanModel_cache(file, model_name=None, **kwargs):
    """Use just as you would `stan`"""
    if file is not None:
        try:
            with io.open(file, 'rt', encoding='utf-8') as f:
                model_code = f.read()
        except:
            raise
    code_hash = md5(model_code.encode('ascii')).hexdigest()
    if model_name is None:
        cache_fn = 'cached-model-{}.pkl'.format(code_hash)
    else:
        cache_fn = 'cached-{}-{}.pkl'.format(model_name, code_hash)
    try:
        sm = pickle.load(open(cache_fn, 'rb'))
    except:
        sm = pystan.StanModel(model_code=model_code)
        with open(cache_fn, 'wb') as f:
            pickle.dump(sm, f)
    else:
        print("Using cached StanModel")
    return sm


def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_type")
    parser.add_argument("--dataset_name")
    parser.add_argument("--test_only", action='store_true')

    args = parser.parse_args()
    return vars(args)


args = get_arguments()

if args["model_type"] == 'logistic_reg':
    model = BayesianLogisticReg(args["dataset_name"], 1, test_only=True)

    os.chdir(model.stan_folder)

    # Assume Y in \in {+1, -1}
    data = {
        'N': model.N,
        'D': model.D,
        'x': model.X,
        'y': (model.Y + 1)/2,
        'sigma': model.sigma,
    }
    parameter_names = ['beta']

elif args["model_type"] == 'linear_reg':
    model = BayesianLinearReg(args["dataset_name"], 1, test_only=True)

    os.chdir(model.stan_folder)

    data = {
        'N': model.N,
        'D': model.D,
        'x': model.X,
        'y': model.Y,
        'sigma': model.sigma,
        'lambda': model.lambd,
    }
    parameter_names = ['beta']

else:
    raise Exception("Model type invalid")

sm = StanModel_cache(file='model_code.stan')

if args["test_only"]:
    fit = sm.sampling(data=data, iter=10, warmup=5, chains=1)

    for _ in range(100):
        parameters = np.random.rand(model.D)
        stan_grad = fit.grad_log_prob(parameters)

        parameters = np.reshape(parameters, (1, parameters.size))
        our_grad = model.dlnprob(parameters, np.arange(model.N))
        assert(np.allclose(stan_grad, our_grad))

    print 'Gradient checks passed'
    sys.exit()

control = {"metric": "dense_e"}

save_prefix = ''
# if len(sys.argv) > 1:
#     i = sys.argv[1]
#     save_prefix = 'run' + i + '_'
fit = sm.sampling(data=data, iter=3000, warmup=500, chains=16, control=control, verbose=True, sample_file='{}sample_file'.format(save_prefix))

print fit.stansummary(digits_summary=5)

fit_extracted = fit.extract()
samples = fit_extracted[parameter_names[0]]
np.savetxt('{}samples.txt'.format(save_prefix), samples)

true_mu = np.mean(samples, axis=0)
true_cov = np.cov(samples, rowvar=False)
true_std = np.sqrt(np.diag(true_cov))

print samples.shape
print true_mu
print true_std

# print fit.summary()
# print fit.extract(permuted=False).shape
# print fit.to_dataframe(permuted=False)
