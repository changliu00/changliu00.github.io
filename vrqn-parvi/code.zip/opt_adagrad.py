from __future__ import division
import numpy as np

# adagrad with momentum

class Opt_Adagrad:

    def __init__(self, stepsize = 1e-3, alpha = 0.9, fudge_factor = 1e-6):
        self.name = 'adagrad'
        self.stepsize = stepsize
        self.alpha = alpha
        self.fudge_factor = fudge_factor
        self.historical_grad = None
        self.epoch = 0

        
    def compute_update(self, grad_theta, *args):
        if self.historical_grad is None:
            self.historical_grad = grad_theta ** 2
        else:
            self.historical_grad = self.alpha * self.historical_grad + (1 - self.alpha) * (grad_theta ** 2)
        adj_grad = np.divide(grad_theta, self.fudge_factor+np.sqrt(self.historical_grad))
        return self.stepsize * adj_grad
    
    def start_epoch(self, theta, model):
        return theta
    
    def end_epoch(self):
        self.epoch += 1

    def compute_n_grad_evals_over_epochs(self, iter, num_iters_per_epoch):
        return self.epoch + iter/float(num_iters_per_epoch)