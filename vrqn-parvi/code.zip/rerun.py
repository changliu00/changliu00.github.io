import os, sys
import subprocess
from ast import literal_eval

def string_to_dict(s):
    list_s = [x.split('=') for x in s.split(',')]
    d_s = {x[0]: x[1] for x in list_s}
    return d_s

def main():
    if len(sys.argv) > 1:
        CURRENT_ALL_EXPS_FOLDER = sys.argv[1]
    else:
        CURRENT_ALL_EXPS_FOLDER = 'exps'
    ALL_EXPS_FOLDER = CURRENT_ALL_EXPS_FOLDER + '-with_mmd_ksd_metrics'


    lbfgs_memory_size = CURRENT_ALL_EXPS_FOLDER.split('-')[-2].split('M')[-1]
    vr_num_epochs_initial_sgd = CURRENT_ALL_EXPS_FOLDER.split('_')[-1]

    print CURRENT_ALL_EXPS_FOLDER
    print ALL_EXPS_FOLDER
    print lbfgs_memory_size
    print vr_num_epochs_initial_sgd

    log_file = os.path.join('..', CURRENT_ALL_EXPS_FOLDER, 'log.txt')

    with open(log_file, "r") as f:
        for line in f:
            EXP_FOLDER, exp_args = line.split(':')
            EXP_FOLDER = EXP_FOLDER.split('/')[0]
            dataset = EXP_FOLDER.split('-')[-2]
            print dataset
            num_epochs = EXP_FOLDER.split('-')[-1].split('epochs')[0]
            exp_args = exp_args.strip()
            exp_args = literal_eval(exp_args)

            if 'linear_reg' in EXP_FOLDER:
                MODEL_TYPE = 'linear_reg'
            elif 'logistic_reg' in EXP_FOLDER:
                MODEL_TYPE = 'logistic_reg'
            else:
                raise Exception()
            
            MAX_BG_PROCS = 11

            for i in range(len(exp_args)):
                args = string_to_dict(exp_args[i].rstrip(".txt"))
                OPT = args['opt']
                lr_factor = args['lr_factor']
                EXP = "q0=1.0,M=100,B=10"
                B = '10'
                M = '100'
                q0 = '1.0'
                lr_decay = args['lr_decay']
                power = args['power']
                MKDIR_COMMAND = "mkdir -p ../{ALL_EXPS_FOLDER}/{EXP_FOLDER}/logs/{EXP}".format(**locals())
                RUN_COMMAND = "nohup python -u main.py --model_type {MODEL_TYPE} --dataset {dataset} --opt {OPT} --lr_factor {lr_factor} --num_epochs {num_epochs} --all_exps_folder {ALL_EXPS_FOLDER} --exp_folder {EXP_FOLDER} --exp {EXP} --B {B} --M {M} --q0 {q0} --lr_decay {lr_decay} --power {power} --lbfgs_memory_size {lbfgs_memory_size} --vr_num_epochs_initial_sgd {vr_num_epochs_initial_sgd} --compute_mmd_ksd_metrics > ../{ALL_EXPS_FOLDER}/{EXP_FOLDER}/logs/{EXP}/{OPT}_lr{lr_factor}_lrdecay{lr_decay}_power{power}.txt 2>&1 &".format(**locals())
                subprocess.call("bash -ic 'set -o noclobber; source max_bg_procs.sh; max_bg_procs {}; {}; {}'".format(MAX_BG_PROCS, MKDIR_COMMAND, RUN_COMMAND), shell=True)

main()